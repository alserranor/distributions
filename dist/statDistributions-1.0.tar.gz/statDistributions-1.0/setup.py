from setuptools import setup

setup(name = 'statDistributions',
      version = '1.0',
      description = 'Gaussian and Binominal distributions',
      packages = ['statDistributions'],
      author = 'Alberto Serrano',
      author_email = 'albertoserranoreigosa@gmail.com',
      zip_safe = False)
