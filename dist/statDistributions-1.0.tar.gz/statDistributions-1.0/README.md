# Statistical Distributions Package for Python

Python package for statistical distribution

# Installation

Installation is by standard pip command:

pip install statDistributions

# Files

The files contained in the package are the following